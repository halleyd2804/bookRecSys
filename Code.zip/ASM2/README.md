<h1> COMP20008 Element of Data Processing </h1>

## About the project
This is a folder which contains the source code for our project. The preprocessing, data exploration, and the machine learning model is included in the <a href="project.ipynb"> notebook (Project.ipynb) </a>

## Contribution
The source code is contributed by:
- Anh Duc Bui (1385532): anhducb@student.unimelb.edu.au
- Thi Hong Minh Dao (1389069): thihongminhd@student.unimelb.edu.au
- Yufan Wu (1455825): yufanw7@student.unimelb.edu.au

## References
### Matrix Factorisation Collaborative Filtering:
- Sezginildes. (2021, June 15). Model based collaborative filtering: Matrix factor. Kaggle. https://www.kaggle.com/code/sezginildes/model-based-collaborative-filtering-matrix-factor 
- Li, S. (2019a, September 26). Building and testing recommender systems with surprise, step-by-step. Medium. https://towardsdatascience.com/building-and-testing-recommender-systems-with-surprise-step-by-step-d4ba702ef80b 

### TF-IDF Content-based Reccomendation System
- Kang, C. (2020, July 17). TF-IDF and similarity scores. Chan`s Jupyter. https://goodboychan.github.io/python/datacamp/natural_language_processing/2020/07/17/04-TF-IDF-and-similarity-scores.html#Building-tf-idf-document-vectors 